"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.subtract = void 0;
var subtract = function (number1, number2) { return number1 - number2; };
exports.subtract = subtract;
