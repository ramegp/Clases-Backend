"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.sum = void 0;
var sum = function (number1, number2) { return number1 + number2; };
exports.sum = sum;
