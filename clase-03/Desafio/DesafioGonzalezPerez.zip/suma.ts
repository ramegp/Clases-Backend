export const sum = (number1: number, number2: number) => { return number1 + number2 }
